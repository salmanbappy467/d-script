'use strict';

/** @type {import('./round')} */
module.exports = Math.round;
